create definer = root@localhost view view_name as
select `a`.`answers_id`                      AS `id`,
       `jackbox`.`external_user`.`team_name` AS `team_name`,
       `a`.`question_number`                 AS `question_number`,
       `a`.`answer`                          AS `answer`
from (`jackbox`.`external_user` left join `jackbox`.`answers` `a`
      on ((`jackbox`.`external_user`.`user_id` = `a`.`user_id`)));

